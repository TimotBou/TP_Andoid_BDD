package timbou.btssn.tp_prog_bdd;

import androidx.appcompat.app.AppCompatActivity;

//import androidx.appcompat.app.AppCompatActivity;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationBarView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ResultSet rst=null;
    public static Connection conn = null;
    private EditText edtidPseudo, edtidMDP, edtidCMDP ;
    private Spinner edtidAsso ;
    private Button btnOk;
    Spinner spinnAsso;
    String ip, db, user, mdp;
    Connection connect;
    PreparedStatement stmt;
    ResultSet rs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ip = "192.168.43.186:3306";
        user = "TimTIm";
        mdp = "1234";
        db = "appandroid";

        spinnAsso = (Spinner) findViewById(R.id.idAsso);
        String query = "select Asso from infos";

        try {
            connect = connexion(user, mdp, db, ip);
            stmt = connect.prepareStatement(query);
            rs = stmt.executeQuery();
            ArrayList<String> data = new ArrayList<>();
            while (rs.next()) {
                String Asso = rs.getString("Asso");
                data.add(Asso);
            }
            String[] array = data.toArray(new String[0]);
            ArrayAdapter NoCoreAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, data);
            spinnAsso.setAdapter(NoCoreAdapter);
        }catch (SQLException e){
            e.printStackTrace();
        }
        spinnAsso.setOnItemSelectedListener(new OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){
                String name = spinnAsso.getSelectedItem().toString();
                Toast.makeText(MainActivity.this, name, Toast.LENGTH_LONG).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent){

            }
        });}

/*        StrictMode.setThreadPolicy(new
                StrictMode.ThreadPolicy.Builder()
                .detectDiskReads()
                .detectDiskWrites()
                .detectNetwork()
                .penaltyLog()
                .build());
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
                .detectLeakedSqlLiteObjects()
                .penaltyLog()
                .penaltyDeath()
                .build());

        MysqlConnexion();

        edtidPseudo = (EditText) findViewById(R.id.idPseudo);
        edtidMDP = (EditText) findViewById(R.id.idMDP);
        edtidCMDP = (EditText) findViewById(R.id.idCMDP);
        edtidAsso = (Spinner) findViewById(R.id.idAsso);

        btnOk = (Button)findViewById(R.id.idOk);
        btnOk.setOnClickListener(this);
    }*/
    @SuppressLint("NewApi")
    private Connection connexion(String user, String mdp, String db, String ip){
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);
        Connection conn = null;
        String ConnURL = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            ConnURL = "jdbc:mysql://" + this.ip + "/" + this.db + "";
            conn = DriverManager.getConnection(ConnURL, this.user, this.mdp);
            Toast.makeText(MainActivity.this, "Connexion établie", Toast.LENGTH_LONG).show();

        }catch (SQLException se) {
            Toast.makeText(MainActivity.this, "Echec lors de la connexion", Toast.LENGTH_LONG).show();
            Log.e("ERRO", se.getMessage());

        }
        catch (ClassNotFoundException e) {
            Log.e("ERRO", e.getMessage());
        }catch (Exception e){
            Log.e("ERRO", e.getMessage());
        }
        return conn;
    }

/*    private void MysqlConnexion(){
        String jdbcURL = "jdbc:mysql://192.168.43.186:3306/android";
        String user = "TimTim";
        String passwd= "1234";

        try{
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(jdbcURL,user,passwd);
        }catch (ClassNotFoundException e){
            Toast.makeText(MainActivity.this, "Driver manquant." + e.getMessage().toString(), Toast.LENGTH_LONG).show();
        }catch (java.sql.SQLException ex){
            Toast.makeText(MainActivity.this, "Connexion au serveur impossible." + ex.getMessage().toString(), Toast.LENGTH_LONG).show();
            Log.d("error", "SQLException: " + ex.getMessage());
            Log.d("error","SQLState: " + ex.getSQLState());
            Log.d("error","VendorError: " + ex.getErrorCode());

        }
    }*/
    @Override
    public void onClick(View view) {


        if(view==btnOk) {
            try {
                String sqlins = "insert into  (idPseudo, idMDP, idCMDP) values (?,?,?,?)";
                PreparedStatement pstmins = conn.prepareStatement(sqlins);
                pstmins.setString(1,edtidCMDP.getText().toString());
                pstmins.setString(2,edtidMDP.getText().toString());
                pstmins.setString(3,edtidPseudo.getText().toString());
                //pstmins.setString(4,edtidAsso.getspinner().toString());    ", idAsso"
                pstmins.executeUpdate();


            } catch (SQLException seinst) {
                Toast.makeText(MainActivity.this, "liste." + seinst.toString(), Toast.LENGTH_LONG).show();
                Log.d("MainActivity", seinst.getMessage());
            }
        }
    }

}